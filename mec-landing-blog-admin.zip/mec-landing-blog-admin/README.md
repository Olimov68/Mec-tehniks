
# MEC Landing + Blog + Admin (Netlify + Supabase)

## 1) Supabase tayyorlash
1. Supabase project oching.
2. `SQL Editor`ga ushbu jadvalni qo'ying va ishga tushiring:

```sql
create table if not exists posts (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  excerpt text,
  content text not null,
  tags text[] default '{}',
  cover text,
  published boolean default false,
  views int default 0,
  created_at timestamptz default now()
);
```

3. (Ixtiyoriy) RLS yoqilgan bo'lsa, vaqtincha `anon` o'qishga ruxsat:
```sql
alter table posts enable row level security;
create policy "Public read" on posts for select using (true);
-- insert/update/delete faqat serverless function (service role) orqali
```

## 2) Lokal ishga tushirish
```bash
npm i
npm run dev
```
_admin PIN_: `.env` yoki Netlify env da `VITE_ADMIN_PIN` (default 1234).

## 3) Netlify'ga deploy
- GitHub repo yarating va kodni push qiling.
- Netlify → Add new site → Import from Git.
- Build command: `npm run build`
- Publish directory: `dist`
- Functions directory: `netlify/functions`
- Environment variables:
  - `SUPABASE_URL`
  - `SUPABASE_SERVICE_ROLE_KEY`
  - `VITE_ADMIN_PIN` (masalan 2468)

Deploydan so'ng API endpointlar avtomatik:
- `/.netlify/functions/posts-get`
- `/.netlify/functions/posts-upsert`
- `/.netlify/functions/posts-delete`
