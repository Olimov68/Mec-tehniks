import { supabase } from './_supabase.js'

export async function handler(event, context) {
  try {
    const body = JSON.parse(event.body || '{}')
    const payload = {
      id: body.id || undefined,
      title: body.title,
      excerpt: body.excerpt || null,
      content: body.content,
      tags: body.tags || [],
      cover: body.cover || null,
      published: !!body.published,
    }
    // Insert or update
    const { data, error } = await supabase
      .from('posts')
      .upsert(payload, { onConflict: 'id' })
      .select('*')
      .single()
    if (error) throw error
    return { statusCode: 200, body: JSON.stringify(data) }
  } catch (e) {
    return { statusCode: 500, body: JSON.stringify({ error: String(e) }) }
  }
}
