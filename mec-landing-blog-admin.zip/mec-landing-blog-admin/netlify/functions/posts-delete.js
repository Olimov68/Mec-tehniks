import { supabase } from './_supabase.js'

export async function handler(event, context) {
  try {
    const { id } = JSON.parse(event.body || '{}')
    if (!id) return { statusCode: 400, body: JSON.stringify({ error: 'id required' }) }
    const { error } = await supabase.from('posts').delete().eq('id', id)
    if (error) throw error
    return { statusCode: 200, body: JSON.stringify({ ok: true }) }
  } catch (e) {
    return { statusCode: 500, body: JSON.stringify({ error: String(e) }) }
  }
}
