import React, { useEffect, useMemo, useState } from "react"

const IconPlus = (props) => (
  <svg {...props} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 5v14M5 12h14"/></svg>
);
const IconEdit = (props) => (
  <svg {...props} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M11 4h2a2 2 0 0 1 2 2v2"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L7 20l-4 1 1-4 14.5-14.5z"/></svg>
);
const IconTrash = (props) => (
  <svg {...props} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6M14 11v6"/><path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/></svg>
);
const IconSearch = (props) => (
  <svg {...props} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.3-4.3"/></svg>
);
const IconEye = (props) => (
  <svg {...props} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8S1 12 1 12Z"/><circle cx="12" cy="12" r="3"/></svg>
);
const IconShield = (props) => (
  <svg {...props} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
);
const IconLogOut = (props) => (
  <svg {...props} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
);

const cls = (...a) => a.filter(Boolean).join(" ");

function Badge({children}) { return <span className="px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 text-xs">{children}</span>; }
function Button({children, className, ...p}) { return <button {...p} className={cls("px-4 py-2 rounded-xl bg-blue-600 text-white hover:bg-blue-700 transition disabled:opacity-50", className)}>{children}</button>; }
function GhostButton({children, className, ...p}) { return <button {...p} className={cls("px-3 py-2 rounded-xl border border-slate-300 hover:border-blue-500 hover:text-blue-700 transition", className)}>{children}</button>; }
function Input(props) { return <input {...props} className={cls("px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500", props.className)} />; }
function Textarea(props) { return <textarea {...props} className={cls("px-3 py-2 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500", props.className)} />; }

function Navbar({ onAdminClick }) {
  return (
    <header className="sticky top-0 z-40 backdrop-blur bg-white/70 border-b border-slate-200">
      <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
        <a href="#top" className="flex items-center gap-2 group">
          <div className="w-9 h-9 rounded-2xl bg-gradient-to-br from-blue-600 to-cyan-500 shadow-md" />
          <span className="font-bold text-lg tracking-tight group-hover:text-blue-700 transition">MEC TEHNIKS</span>
        </a>
        <nav className="hidden sm:flex items-center gap-6 text-sm">
          <a href="#features" className="hover:text-blue-700">Xususiyatlar</a>
          <a href="#blog" className="hover:text-blue-700">Blog</a>
          <a href="#about" className="hover:text-blue-700">Biz haqimizda</a>
          <a href="#contact" className="hover:text-blue-700">Aloqa</a>
        </nav>
        <GhostButton onClick={onAdminClick} className="text-xs"><IconShield className="w-4 h-4 inline -mt-0.5 mr-1"/> Admin</GhostButton>
      </div>
    </header>
  );
}

function Hero({ onNewPost }) {
  return (
    <section id="top" className="relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-blue-50 to-cyan-50" />
      <div className="absolute inset-0" style={{backgroundImage:"radial-gradient(rgba(0,0,0,0.06) 1px, transparent 1px)", backgroundSize:"18px 18px", opacity:.4}} />
      <div className="relative max-w-6xl mx-auto px-4 py-16 sm:py-24 grid sm:grid-cols-2 gap-10">
        <div className="space-y-6">
          <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight">Professional <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-cyan-500">Landing + Blog</span></h1>
          <p className="text-slate-600 text-lg leading-relaxed">Admin panel, postlarni boshqarish, izlash, teglar, qoralama/publish — barchasi. Hozir server API bilan ishlaydi.</p>
          <div className="flex gap-3">
            <Button onClick={onNewPost}><IconPlus className="w-4 h-4 inline -mt-0.5 mr-1"/> Yangi post</Button>
            <GhostButton as="a" href="#features">Xususiyatlar</GhostButton>
          </div>
        </div>
        <div className="relative">
          <div className="absolute -inset-4 bg-gradient-to-tr from-blue-200/50 to-cyan-200/40 blur-2xl rounded-3xl" />
          <div className="relative bg-white border border-slate-200 rounded-3xl p-6 shadow-sm">
            <div className="font-semibold mb-3">Qisqa ko'rinish</div>
            <ul className="space-y-2 text-sm text-slate-600">
              <li>• Admin panel: CRUD, qoralama/publish, qidiruv, filtr</li>
              <li>• Netlify Functions + Supabase (posts API)</li>
              <li>• Tailwind dizayn</li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}

function PostCard({ post, onEdit }) {
  const date = new Date(post.created_at || post.createdAt).toLocaleDateString();
  return (
    <article className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm">
      {post.cover ? <img src={post.cover} alt="cover" className="w-full h-36 object-cover rounded-xl mb-3"/> : null}
      <h3 className="font-semibold text-lg">{post.title}</h3>
      <div className="text-xs text-slate-500 mt-1 flex items-center gap-3"><span>{date}</span><span className="flex items-center gap-1"><IconEye className="w-4 h-4"/>{post.views||0}</span></div>
      <p className="text-slate-600 mt-3 line-clamp-3">{post.excerpt || post.content?.slice(0,140)}</p>
      <div className="mt-3 flex flex-wrap gap-2">{(post.tags||[]).map(t=> <Badge key={t}>#{t}</Badge>)}</div>
      <div className="mt-3 flex gap-2">
        <GhostButton onClick={()=>onEdit(post)}><IconEdit className="w-4 h-4 inline -mt-0.5 mr-1"/> Tahrirlash</GhostButton>
      </div>
    </article>
  );
}

function BlogGrid({ posts, onEdit }) {
  if (!posts.length) return <div className="text-slate-500">Hozircha post yo'q.</div>;
  return (
    <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
      {posts.map(p => <PostCard key={p.id} post={p} onEdit={onEdit} />)}
    </div>
  );
}

function Features() {
  return (
    <section id="features" className="max-w-6xl mx-auto px-4 py-14">
      <h2 className="text-2xl sm:text-3xl font-bold mb-8">Nega bu shablon?</h2>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {[{
          title:"Admin Panel",
          desc:"Postlarni yaratish, tahrirlash, qoralama/publish, teglar va qidiruv.",
        },{
          title:"Netlify Functions",
          desc:"Serverless CRUD API (Supabase bilan).",
        },{
          title:"Dizayn",
          desc:"Toza UI, Tailwind, responsiv grid, modal formalar.",
        }].map((f,i)=>(
          <div key={i} className="p-6 rounded-2xl bg-white border border-slate-200 shadow-sm">
            <div className="text-sm font-semibold text-blue-700">{f.title}</div>
            <p className="mt-2 text-slate-600">{f.desc}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

function About() {
  return (
    <section id="about" className="max-w-6xl mx-auto px-4 py-14">
      <div className="grid lg:grid-cols-2 gap-10 items-center">
        <div className="space-y-4">
          <h2 className="text-2xl sm:text-3xl font-bold">Biz haqimizda</h2>
          <p className="text-slate-600">Tez start uchun tayyor shablon. Keyinroq autentifikatsiya va rollarni qo'shish mumkin.</p>
          <ul className="list-disc list-inside text-slate-600">
            <li>Netlify deploy</li>
            <li>Supabase ma'lumotlar bazasi</li>
            <li>Role-based access (keyinroq)</li>
          </ul>
        </div>
        <div className="relative">
          <div className="absolute -inset-4 bg-gradient-to-tr from-blue-200/50 to-cyan-200/40 blur-2xl rounded-3xl" />
          <div className="relative p-6 rounded-3xl bg-white border border-slate-200 shadow-sm">
            <div className="grid grid-cols-3 gap-4 text-center">
              <div className="p-4 rounded-2xl bg-slate-50">
                <div className="text-2xl font-extrabold" id="statPosts">—</div>
                <div className="text-xs text-slate-500">Postlar</div>
              </div>
              <div className="p-4 rounded-2xl bg-slate-50">
                <div className="text-2xl font-extrabold" id="statViews">—</div>
                <div className="text-xs text-slate-500">Ko‘rishlar</div>
              </div>
              <div className="p-4 rounded-2xl bg-slate-50">
                <div className="text-2xl font-extrabold">1</div>
                <div className="text-xs text-slate-500">Kun ichida</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function Contact() {
  return (
    <section id="contact" className="max-w-6xl mx-auto px-4 py-14">
      <div className="rounded-3xl bg-white border border-slate-200 shadow-sm p-6 sm:p-8">
        <h2 className="text-2xl sm:text-3xl font-bold mb-4">Aloqa</h2>
        <p className="text-slate-600 mb-6">Demo forma (backend kerak). API bilan bog'langanidan so'ng ishlaydi.</p>
        <form onSubmit={(e)=>{e.preventDefault(); alert('Demo: backend talab qilinadi.')}} className="grid sm:grid-cols-3 gap-4">
          <Input placeholder="Ism" />
          <Input placeholder="Email" />
          <Button>Yuborish</Button>
        </form>
      </div>
    </section>
  );
}

function Modal({ open, title, children, onClose }) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
      <div className="w-full max-w-2xl rounded-3xl bg-white border border-slate-200 shadow-xl">
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-200">
          <div className="font-semibold">{title}</div>
          <button onClick={onClose} className="text-slate-500 hover:text-slate-700">✕</button>
        </div>
        <div className="p-5">{children}</div>
      </div>
    </div>
  );
}

function EmptyState({ title, desc, action }) {
  return (
    <div className="p-8 text-center border border-dashed border-slate-300 rounded-2xl">
      <div className="text-lg font-semibold">{title}</div>
      <p className="text-slate-600 mt-1">{desc}</p>
      {action}
    </div>
  );
}

function PostEditorModal({ open, onClose, onSave, initial }) {
  const [title, setTitle] = useState(initial?.title || "");
  const [excerpt, setExcerpt] = useState(initial?.excerpt || "");
  const [content, setContent] = useState(initial?.content || "");
  const [tags, setTags] = useState((initial?.tags||[]).join(', '));
  const [cover, setCover] = useState(initial?.cover || "");
  const [published, setPublished] = useState(!!initial?.published);

  React.useEffect(()=>{
    if (open) {
      setTitle(initial?.title || "");
      setExcerpt(initial?.excerpt || "");
      setContent(initial?.content || "");
      setTags((initial?.tags||[]).join(', '));
      setCover(initial?.cover || "");
      setPublished(!!initial?.published);
    }
  }, [open, initial]);

  function onFile(e){
    const f = e.target.files?.[0];
    if (!f) return;
    const reader = new FileReader();
    reader.onload = () => setCover(String(reader.result));
    reader.readAsDataURL(f);
  }

  return (
    <Modal open={open} onClose={onClose} title={initial?"Postni tahrirlash":"Yangi post"}>
      <div className="grid gap-3">
        <Input value={title} onChange={e=>setTitle(e.target.value)} placeholder="Sarlavha"/>
        <Input value={excerpt} onChange={e=>setExcerpt(e.target.value)} placeholder="Qisqa tavsif (excerpt)"/>
        <Textarea rows={8} value={content} onChange={e=>setContent(e.target.value)} placeholder="Maqola matni..."/>
        <Input value={tags} onChange={e=>setTags(e.target.value)} placeholder="Teglar (vergul bilan)"/>
        <div className="flex items-center gap-3">
          <input type="file" accept="image/*" onChange={onFile} className="text-sm"/>
          {cover && <img src={cover} alt="cover" className="h-12 rounded"/>}
        </div>
        <label className="inline-flex items-center gap-2 text-sm"><input type="checkbox" checked={published} onChange={e=>setPublished(e.target.checked)} /> Nashr qilish</label>
        <div className="flex items-center justify-end gap-2 mt-2">
          <GhostButton onClick={onClose}>Bekor qilish</GhostButton>
          <Button onClick={()=>{
            if (!title.trim() || !content.trim()) { alert('Sarlavha va matn shart.'); return; }
            onSave({ title: title.trim(), excerpt: excerpt.trim(), content: content.trim(), tags: tags.split(',').map(t=>t.trim()).filter(Boolean), cover, published });
          }}>Saqlash</Button>
        </div>
      </div>
    </Modal>
  );
}

function AdminPanel({ posts, setPosts, onClose, onEdit }) {
  const [search, setSearch] = useState("");
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [filter, setFilter] = useState("all"); // all | published | draft

  const filtered = posts
    .filter(p => filter === "all" ? true : filter === "published" ? p.published : !p.published)
    .filter(p => (p.title+" "+(p.content||"")+" "+(p.tags||[]).join(",")).toLowerCase().includes(search.toLowerCase()))
    .sort((a,b)=> new Date(b.created_at||b.createdAt) - new Date(a.created_at||a.createdAt));

  function openCreate() { setEditing(null); setModalOpen(true); }
  function openEdit(p) { setEditing(p); setModalOpen(true); }

  async function remove(id) {
    if (!confirm("Haqiqatan ham o'chirasizmi?")) return;
    await fetch("/.netlify/functions/posts-delete", { method:"POST", headers:{ "Content-Type":"application/json" }, body: JSON.stringify({ id }) });
    onEdit(); // reload
  }

  return (
    <div className="fixed inset-0 z-50 grid lg:grid-cols-[280px_1fr] bg-white">
      <aside className="hidden lg:flex flex-col border-r border-slate-200 p-4 gap-3">
        <div className="font-bold text-lg">Admin Panel</div>
        <button onClick={openCreate} className="px-4 py-2 rounded-xl bg-blue-600 text-white hover:bg-blue-700"><IconPlus className="w-4 h-4 inline -mt-0.5 mr-1"/> Yangi post</button>
        <div className="mt-2">
          <div className="text-xs text-slate-500 mb-1">Filtr</div>
          <div className="flex flex-col gap-2">
            <GhostButton onClick={()=>setFilter("all")} className={filter==="all"?"border-blue-500 text-blue-700":""}>Barchasi</GhostButton>
            <GhostButton onClick={()=>setFilter("published")} className={filter==="published"?"border-blue-500 text-blue-700":""}>Nashr qilingan</GhostButton>
            <GhostButton onClick={()=>setFilter("draft")} className={filter==="draft"?"border-blue-500 text-blue-700":""}>Qoralamalar</GhostButton>
          </div>
        </div>
        <div className="mt-auto" />
        <GhostButton onClick={onClose}><IconLogOut className="w-4 h-4 inline -mt-0.5 mr-1"/> Chiqish</GhostButton>
      </aside>

      <main className="min-w-0 p-4">
        <div className="flex items-center gap-2 mb-4">
          <div className="relative w-full">
            <IconSearch className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2"/>
            <Input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Qidirish..." className="pl-9 w-full"/>
          </div>
          <Button onClick={openCreate} className="hidden sm:inline-flex"><IconPlus className="w-4 h-4 inline -mt-0.5 mr-1"/> Yangi</Button>
        </div>

        {filtered.length === 0 ? (
          <div className="p-8 text-center border border-dashed border-slate-300 rounded-2xl">
            <div className="text-lg font-semibold">Hali post yo'q</div>
            <p className="text-slate-600 mt-1">Yangi post yarating va nashr qiling.</p>
            <div className="mt-4"><Button onClick={openCreate}>Yangi post</Button></div>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left border-b border-slate-200">
                  <th className="py-3 pr-3">Sarlavha</th>
                  <th className="py-3 pr-3">Teglar</th>
                  <th className="py-3 pr-3">Holat</th>
                  <th className="py-3 pr-3">Sana</th>
                  <th className="py-3 pr-3 text-right">Amallar</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map(p => (
                  <tr key={p.id} className="border-b border-slate-100 hover:bg-slate-50">
                    <td className="py-3 pr-3 font-medium max-w-[360px] truncate">{p.title}</td>
                    <td className="py-3 pr-3 text-slate-600">{(p.tags||[]).map(t=>`#${t}`).join(', ')}</td>
                    <td className="py-3 pr-3"><span className={p.published?"px-2 py-0.5 rounded-full text-xs bg-green-100 text-green-700":"px-2 py-0.5 rounded-full text-xs bg-amber-100 text-amber-700"}>{p.published?"Nashr":"Qoralama"}</span></td>
                    <td className="py-3 pr-3 text-slate-500">{new Date(p.created_at||p.createdAt).toLocaleDateString()}</td>
                    <td className="py-3 pr-3 text-right">
                      <GhostButton onClick={()=>openEdit(p)} className="mr-2"><IconEdit className="w-4 h-4 inline -mt-0.5 mr-1"/> Tahrir</GhostButton>
                      <GhostButton onClick={()=>remove(p.id)} className="border-red-300 text-red-600 hover:bg-red-50"><IconTrash className="w-4 h-4 inline -mt-0.5 mr-1"/> O‘chirish</GhostButton>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        <PostEditorModal open={modalOpen} onClose={()=>setModalOpen(false)} onSave={async (np)=>{
          let body = np;
          if (editing) body = { id: editing.id, ...np };
          const url = editing ? "/.netlify/functions/posts-upsert" : "/.netlify/functions/posts-upsert";
          await fetch(url, { method:"POST", headers:{ "Content-Type":"application/json" }, body: JSON.stringify(body) });
          setModalOpen(false);
          onEdit(); // reload
        }} initial={editing} />
      </main>
    </div>
  );
}

function AuthModal({ open, onClose, onAuth }) {
  const [pin, setPin] = useState("");
  const correctPin = import.meta.env.VITE_ADMIN_PIN || "1234";

  if (!open) return null;
  return (
    <Modal open={open} onClose={onClose} title={"Admin kirish"}>
      <div className="grid gap-3">
        <Input type="password" value={pin} onChange={e=>setPin(e.target.value)} placeholder="PIN"/>
        <div className="flex items-center justify-end gap-2">
          <GhostButton onClick={onClose}>Bekor</GhostButton>
          <Button onClick={()=>{
            if (pin.trim() === String(correctPin)) onAuth(); else alert('Noto\\'g\\'ri PIN');
          }}>Kirish</Button>
        </div>
      </div>
    </Modal>
  );
}

export default function App() {
  const [posts, setPosts] = useState([]);
  const [authOpen, setAuthOpen] = useState(false);
  const [adminOpen, setAdminOpen] = useState(false);
  const [query, setQuery] = useState("");

  const publicPosts = useMemo(()=> posts.filter(p=>p.published)
    .filter(p => (p.title+" "+(p.content||"")+" "+(p.tags||[]).join(",")).toLowerCase().includes(query.toLowerCase()))
    .sort((a,b)=> new Date(b.created_at||b.createdAt) - new Date(a.created_at||a.createdAt)), [posts, query]);

  async function loadPosts(){
    const res = await fetch("/.netlify/functions/posts-get");
    const data = await res.json();
    setPosts(Array.isArray(data)?data:[]);
  }

  useEffect(()=>{ loadPosts(); }, []);

  function newPostFromHero(){
    setAuthOpen(true);
  }

  return (
    <div className="bg-slate-50 text-slate-800 min-h-screen">
      <Navbar onAdminClick={()=> setAuthOpen(true)} />
      <Hero onNewPost={newPostFromHero} />

      <section id="blog" className="max-w-6xl mx-auto px-4 py-14">
        <div className="flex items-end justify-between gap-4 mb-6">
          <div>
            <h2 className="text-2xl sm:text-3xl font-bold">Blog postlari</h2>
            <p className="text-slate-600">So‘nggi yangiliklar va maqolalar.</p>
          </div>
          <div className="flex items-center gap-2">
            <div className="relative">
              <IconSearch className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2"/>
              <Input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Qidirish..." className="pl-9"/>
            </div>
            <GhostButton onClick={newPostFromHero}><IconPlus className="w-4 h-4 inline -mt-0.5 mr-1"/> Post</GhostButton>
          </div>
        </div>
        <BlogGrid posts={publicPosts} onEdit={()=> setAuthOpen(true)} />
      </section>

      <Features />
      <About />
      <Contact />

      <footer className="border-t border-slate-200 py-10 text-sm">
        <div className="max-w-6xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="text-slate-500">© {new Date().getFullYear()} MEC TEHNIKS. Barcha huquqlar himoyalangan.</div>
          <div className="flex items-center gap-3 text-slate-500">
            <a href="#top" className="hover:text-blue-700">Yuqoriga</a>
            <span>·</span>
            <a href="#blog" className="hover:text-blue-700">Blog</a>
          </div>
        </div>
      </footer>

      <AuthModal open={authOpen} onClose={()=>setAuthOpen(false)} onAuth={()=>{ setAuthOpen(false); setAdminOpen(true); }} />

      {adminOpen && (
        <AdminPanel posts={posts} setPosts={setPosts} onClose={()=> setAdminOpen(false)} onEdit={loadPosts} />
      )}
    </div>
  );
}
